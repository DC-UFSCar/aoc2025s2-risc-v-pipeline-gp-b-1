git pull
cat .password
unzip gabaritos.zip
zip -e gabaritos.zip */*/*.gabarito
