# [Home](https://menotti.pro.br/aoc)

## Arquitetura e Organização de Computadores 

Material da parte prática, a qual ministrei mais recentemente.

[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://codespaces.new/menotti/aoc)

## Referências
- [Digital Design and Computer Architecture, RISC-V Edition](https://shop.elsevier.com/books/digital-design-and-computer-architecture-risc-v-edition/harris/978-0-12-820064-3)
- [From Blinker to RISC-V](https://github.com/BrunoLevy/learn-fpga/blob/master/FemtoRV/TUTORIALS/FROM_BLINKER_TO_RISCV/)
- http://www.riscbook.com/portuguese/
- https://riscv-programming.org/
- https://www.riscvschool.com/
- https://menotti.pro.br/mm/