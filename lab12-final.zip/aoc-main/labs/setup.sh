sudo apt update && sudo apt install iverilog gcc-riscv64-linux-gnu binutils-riscv64-linux-gnu qemu-user qemu-user-static

